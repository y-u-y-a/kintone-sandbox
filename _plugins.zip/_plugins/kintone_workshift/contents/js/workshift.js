/*
*--------------------------------------------------------------------
* Kintone-Plugin "workshift"
* Version: 1.0
* Copyright (c) 2016 TIS
*
* Released under the MIT License.
* http://tis2010.jp/license.txt
* -------------------------------------------------------------------
*/
jTis.noConflict();
(function($,PLUGIN_ID){
	"use strict";
	/*---------------------------------------------------------------
	 valiable
	---------------------------------------------------------------*/
	var vars={
		fromdate:new Date(),
		todate:new Date(),
		calendar:null,
		dateinfo:null,
		form:null,
		legend:null,
		table:null,
		toolbar:null,
		apps:{},
		config:{},
		worktimes:{},
		schedule:{
			records:[]
		},
		fieldinfos:{},
		colors:[],
		editables:[]
	};
	var events={
		lists:[
			'app.record.index.show'
		],
		show:[
			'app.record.create.show'
		]
	};
	var functions={
		/* adjust pickup dates */
		adjustdates:function(){
			var week=['日','月','火','水','木','金','土'];
			switch ($('select.viewtype').val())
			{
				case '0':
					vars.todate=new Date(vars.fromdate.format('Y-m-d').dateformat());
					$('.datedisplay').css({'display':'inline-block'}).text(vars.fromdate.format('Y-m-d')+' ('+week[vars.fromdate.getDay()]+')');
					$('.weekdisplay').css({'display':'none'});
					$('.monthdisplay').css({'display':'none'});
					$('.calendar-button').css({'display':'inline-block'});
					break;
				case '1':
					vars.fromdate.setDate(vars.fromdate.getDate()+vars.fromdate.getDay()*-1);
					vars.todate=vars.fromdate.calc('6 day');
					$('.datedisplay').css({'display':'none'});
					$('.weekdisplay').css({'display':'inline-block'}).text(vars.fromdate.format('Y-m-d')+' ～ '+vars.todate.format('Y-m-d'));
					$('.monthdisplay').css({'display':'none'});
					$('.calendar-button').css({'display':'none'});
					break;
				case '2':
					vars.fromdate=vars.fromdate.calc('first-of-month');
					vars.todate=vars.fromdate.calc('1 month').calc('-1 day');
					$('.datedisplay').css({'display':'none'});
					$('.weekdisplay').css({'display':'none'});
					$('.monthdisplay').css({'display':'inline-block'}).text(vars.fromdate.format('Y-m-d')+' ～ '+vars.todate.format('Y-m-d'));
					$('.calendar-button').css({'display':'none'});
					break;
			}
			vars.fromdate=new Date((vars.fromdate.format('Y-m-d')+'T00:00:00'+$.timezome()).dateformat());
			vars.todate=new Date((vars.todate.format('Y-m-d')+'T23:59:59'+$.timezome()).dateformat());
			vars.dateinfo=$.datecalc(vars.fromdate,vars.todate);
		},
		/* download work schedule file */
		downloadschedule:function(){
			var fromdate=new Date((vars.fromdate.format('Y-m')+'-01').dateformat());
			var todate=fromdate.calc('1 month').calc('-1 day');
			var week=['日','月','火','水','木','金','土'];
			/* setup font */
			pdfMake.fonts={
				GenShinGothic:{
					normal:'GenShinGothic-Normal.ttf'
				}
			};
			/* reload datas */
			vars.schedule.records=[];
			functions.loaddatas(kintone.app.getId(),(function(fromdate,todate){
				var res=kintone.app.getQueryCondition();
				if (res) res='('+res+') and ';
				res+=vars.config['shiftfromtime']+'>"'+fromdate.calc('-1 day').format('Y-m-d')+'T23:59:59'+$.timezome()+'"';
				res+=' and '+vars.config['shiftfromtime']+'<"'+todate.calc('1 day').format('Y-m-d')+'T00:00:00'+$.timezome()+'"';
				return res;
			})(fromdate,todate),vars.config['shiftfromtime']+' asc',function(records){
				vars.schedule.records=records;
				var definition={
					content:[],
					defaultStyle:{
						font:'GenShinGothic',
						fontSize:11
					},
					styles:{
						caption:{
							margin:[5,0,0,0]
						},
						title:{
							alignment:'center',
							fontSize:18
						},
						table:{
							margin:[0,5,0,0]
						},
						tablecellcaption:{
							alignment:'center'
						},
						tablecellcontent:{
							alignment:'left'
						},
						tableheader:{
							alignment:'center'
						}
					}
				};
				var assignments=function(employee){
					var res='';
					for (var i=0;i<employee.assignment.length;i++) res+=vars.apps['assignment'][employee.assignment[i]]+',';
					return res.replace(/,$/g,'');
				}
				var worktimes=function(date,records){
					var filter=$.grep(records,function(item,index){
						return new Date(item[vars.config['shiftfromtime']].value.dateformat()).format('Y-m-d')==date.format('Y-m-d');
					});
					var res='';
					for (var i=0;i<filter.length;i++)
					{
						res+=new Date(filter[i][vars.config['shiftfromtime']].value.dateformat()).format('H:i')+' - ';
						res+=new Date(filter[i][vars.config['shifttotime']].value.dateformat()).format('H:i')+' , ';
					}
					return res.replace(/ , $/g,'');
				};
				for (var i=0;i<vars.apps['employee'].length;i++)
				{
					var day=fromdate;
					var employee=vars.apps['employee'][i];
					var filter=$.grep(vars.schedule.records,function(item,index){
						var exists=false;
						var fieldinfo=vars.fieldinfos[vars.config['employee']];
						switch (fieldinfo.type)
						{
							case 'USER_SELECT':
								for (var i2=0;i2<item[vars.config['employee']].value.length;i2++)
									if (item[vars.config['employee']].value[i2].code==employee.value) exists=true;
								break;
							default:
								if (item[vars.config['employee']].value==employee.value) exists=true;
								break;
						}
						return exists;
					});
					var table={
						widths:[30,30,'*'],
						body:[
							[
								{text:'日',style:'tableheader'},
								{text:'曜日',style:'tableheader'},
								{text:'勤務時間',style:'tableheader'},
							]
						]
					};
					/* build table rows */
					for (var i2=0;i2<todate.getDate();i2++)
					{
						table.body.push([
							{text:day.format('d'),style:'tablecellcaption'},
							{text:week[day.getDay()],style:'tablecellcaption'},
							{text:worktimes(day,filter),style:'tablecellcontent'}
						]);
						day=day.calc('1 day');
					}
					/* build pdf contents */
					definition.content.push({text:fromdate.getFullYear().toString()+'年'+(fromdate.getMonth()+1).toString()+'月勤務予定表',style:'title'});
					definition.content.push({
						columns:[
							{text:'氏名',style:'caption',width:50},
							{text:employee.display,width:'auto'}
						]
					});
					if (vars.config['assignment'].length!=0)
						definition.content.push({
							columns:[
								{text:'配属先',style:'caption',width:50},
								{text:assignments(employee),width:'auto'}
							]
						});
					if (i<vars.apps['employee'].length-1) definition.content.push({table:table,pageBreak:'after',style:'table'});
					else definition.content.push({table:table,style:'table'});
				}
				/* download */
				if (window.navigator.msSaveBlob)
				{
					/* IE */
					pdfMake.createPdf(definition).download('schedule'+fromdate.format('Y-m')+'.pdf');
				}
				else
				{
					/* Others */
					pdfMake.createPdf(definition).open();
				}
			});
		},
		/* display calculate worktime */
		displayworktime:function(){
			vars.legend.empty();
			for (var key in vars.worktimes)
			{
				var time=Math.floor(vars.worktimes[key].time/60).toString()+'時間'+(vars.worktimes[key].time%60).toString()+'分';
				vars.legend.append(
					$('<p>')
					.append($('<span>').addClass('color').css({'background-color':'#'+vars.worktimes[key].color}))
					.append($('<span>').text(vars.worktimes[key].display+'：'+time))
				);
			}
			$(window).trigger('resize');
		},
		/* reload view */
		load:function(){
			/* after apprecords acquisition,rebuild view */
			functions.loaddatas(kintone.app.getId(),(function(){
				var res=kintone.app.getQueryCondition();
				if (res) res='('+res+') and ';
				res+='(';
				res+='(';
				res+=vars.config['shiftfromtime']+'>"'+vars.fromdate.calc('-1 day').format('Y-m-d')+'T23:59:59'+$.timezome()+'"';
				res+=' and '+vars.config['shiftfromtime']+'<"'+vars.todate.calc('1 day').format('Y-m-d')+'T00:00:00'+$.timezome()+'"';
				res+=')';
				res+=' or ';
				res+='(';
				res+=vars.config['shifttotime']+'>"'+vars.fromdate.calc('-1 day').format('Y-m-d')+'T23:59:59'+$.timezome()+'"';
				res+=' and '+vars.config['shifttotime']+'<"'+vars.todate.calc('1 day').format('Y-m-d')+'T00:00:00'+$.timezome()+'"';
				res+=')';
				res+=')';
				return res;
			})(),vars.config['shiftfromtime']+' asc',function(records){
				var unitminute=60/parseInt(vars.config['scale']);
				var container=$('div#workshift-container').empty();
				var head=$('<tr></tr><tr></tr><tr></tr>');
				var template=$('<tr>');
				var columns={cache:vars.fromdate,index:1,span:0};
				var week=['日','月','火','水','木','金','土'];
				var addrow=function(filter,heads,colorindex){
					var color=vars.colors[colorindex%vars.colors.length];
					/* initialize valiable */
					if (!(heads.value in vars.worktimes)) vars.worktimes[heads.value]={color:color,display:heads.display,time:0};
					/* append row */
					vars.table.addrow(null,function(row){
						var cells=row.append($('<input type="hidden" id="recordkeys">').val(JSON.stringify(heads))).find('td');
						cells.eq(0).html((heads.link)?heads.link:heads.display);
						/* add clips */
						addclips(row,filter);
					});
				}
				var addclips=function(row,filter){
					var clip=$('<div class="workshift-clip" draggable="true">');
					var recordkeys=JSON.parse(row.find('#recordkeys').val());
					var levels=[];
					$('.workshift-clip',row).remove();
					$('.workshift-cell',row).css({'padding-top':'30px'});
					/* initialize valiable */
					vars.worktimes[recordkeys.value].time=0;
					for (var i=0;i<filter.length;i++)
						(function(record){
							var clipinfo=(function(record){
								var from=(function(clipfromdate){
									return (vars.fromdate<clipfromdate)?clipfromdate:vars.fromdate;
								})(new Date(record[vars.config['shiftfromtime']].value.dateformat()));
								var to=(function(cliptodate){
									return (vars.todate>cliptodate)?cliptodate:vars.todate;
								})(new Date(record[vars.config['shifttotime']].value.dateformat()));
								return {
									fromdate:from,
									todate:to,
									height:28,
									pos:(function(dateinfo){
										var cells=row.find('.workshift-cell');
										var from=(dateinfo.from.hour*parseInt(vars.config['scale']))+Math.floor(dateinfo.from.minute/unitminute);
										var to=(dateinfo.to.hour*parseInt(vars.config['scale']))+Math.ceil(dateinfo.to.minute/unitminute)-1;
										if (from<0) from=0;
										if (to>(vars.dateinfo.diffhours*parseInt(vars.config['scale']))-1) to=(vars.dateinfo.diffhours*parseInt(vars.config['scale']))-1;
										from=(function(from){
											var res=from;
											for (var i2=from;i2<cells.length;i2++) if (!cells.eq(i2).hasClass('hide')) {res=i2;break;}
											return res;
										})(from);
										to=(function(to){
											var res=to;
											for (var i2=to;i2>0;i2--) if (!cells.eq(i2).hasClass('hide')) {res=i2;break;}
											return res;
										})(to);
										/* calculate worktime */
										vars.worktimes[recordkeys.value].time+=dateinfo.diffminutes;
										return {
											from:from+1,
											to:to+1
										};
									})($.datecalc(from,to,vars.fromdate))
								};
							})(record)
							if (clipinfo.pos.from>clipinfo.pos.to) return;
							var cell=row.find('td').eq(clipinfo.pos.from);
							var cellheight=(function(){
								var res=0;
								var matchlevel=-1;
								for (var i2=0;i2<levels.length;i2++)
								{
									if ($.grep(levels[i2].dates,function(item,index){
										var exists=false;
										if (clipinfo.fromdate>=item.from && clipinfo.fromdate<=item.to) exists=true;
										if (clipinfo.todate>=item.from && clipinfo.todate<=item.to) exists=true;
										if (clipinfo.fromdate<=item.from && clipinfo.todate>=item.to) exists=true;
										return exists;
									}).length==0)
									{
										matchlevel=i2;
										levels[i2].dates.push({
											from:clipinfo.fromdate,
											to:clipinfo.todate.calc('-1 second')
										});
										if (levels[i2].height<clipinfo.height) levels[i2].height=clipinfo.height;
										break;
									}
									else res+=levels[i2].height;
								}
								if (matchlevel<0)
								{
									levels.push({
										dates:[{
											from:clipinfo.fromdate,
											to:clipinfo.todate.calc('-1 second')
										}],
										height:clipinfo.height
									});
								}
								return res+clipinfo.height;
							})()
							cell.css({
								'padding-top':(cellheight+2).toString()+'px'
							})
							.append(vars.table.draggableclip(
								clip.clone(true).css({
									'background-color':'#'+vars.worktimes[recordkeys.value].color,
									'top':(cellheight-clipinfo.height+2).toString()+'px',
									'width':(function(from,to){
										var res=0;
										res+=vars.table.cols[to][2][0].getBoundingClientRect().right;
										res-=vars.table.cols[from][2][0].getBoundingClientRect().left;
										return (Math.abs(res)-5).toString();
									})(clipinfo.pos.from,clipinfo.pos.to)+'px',
									'z-index':$('.workshift-cell').length.toString()
								})
								.append($('<input type="hidden" class="workshift-clipspanfrom">').val(clipinfo.pos.from))
								.append($('<input type="hidden" class="workshift-clipspanto">').val(clipinfo.pos.to))
								.append(
									$('<span class="workshift-edit">').css({
										'border-color':'#'+vars.worktimes[recordkeys.value].color
									})
									.on('click',function(e){
										/* show registration form */
										if (vars.config['pagetransfer']=='1')
										{
											window.location.href=kintone.api.url('/k/', true).replace(/\.json/g,'')+kintone.app.getId()+'/show#record='+record['$id'].value.toString()+'&mode=edit'+$.breadcrumbsparams();
											return;
										}
										vars.form.dialog.container.children('div').eq(1).find('#record').css({'display':'inline-block'});
										vars.form.dialog.container.children('div').eq(1).find('#duplicate').css({'display':'inline-block'});
										vars.form.dialog.container.children('div').eq(1).find('#delete').css({'display':'inline-block'});
										vars.form.show({
											buttons:{
												ok:function(){
													/* update record */
													kintone.api(kintone.api.url('/k/v1/record',true),'PUT',{app:kintone.app.getId(),id:record['$id'].value,record:(function(){
														var res={};
														/* create update values */
														res[vars.config['shiftfromtime']]=vars.form.fieldvalue(vars.fieldinfos[vars.config['shiftfromtime']]);
														res[vars.config['shifttotime']]=vars.form.fieldvalue(vars.fieldinfos[vars.config['shifttotime']]);
														for (var i2=0;i2<vars.editables.length;i2++) res[vars.editables[i2]]=vars.form.fieldvalue(vars.fieldinfos[vars.editables[i2]]);
														return res;
													})()},function(resp){
														kintone.api(kintone.api.url('/k/v1/record',true),'GET',{app:kintone.app.getId(),id:record['$id'].value},function(resp){
															var filter=$.grep(records,function(item,index){
																return item['$id'].value==resp.record['$id'].value;
															});
															for (var key in vars.fieldinfos)
																if (!vars.fieldinfos[key].tablecode) filter[0][key]=resp.record[key];
															/* reload clips */
															addclips(row,$.grep(records,function(item,index){
																return $.fieldequals(item[vars.config['employee']].value,record[vars.config['employee']].value,vars.fieldinfos[vars.config['employee']]);
															}));
															/* close form */
															vars.form.hide();
														},function(error){
															swalTis('Error!',$.builderror(error),'error');
															/* close form */
															vars.form.hide();
														});
													},function(error){
														swalTis('Error!',$.builderror(error),'error');
														/* close form */
														vars.form.hide();
													});
												},
												duplicate:function(){
													var recordid=record['$id'].value;
													if (recordid)
													{
														swalTis({
															title:'確認',
															text:'レコードを複製します。\n宜しいですか?',
															icon:'info',
															buttons:{
																cancel:{
																	text:'キャンセル',
																	visible:true
																},
																confirm:{
																	text:'OK',
																	visible:true
																}
															}
														}).then(function(isConfirm){
															if (!isConfirm) return;
															$.duplicaterecord(kintone.app.getId(),recordid,function(duplicaterecord){
																/* reload clips */
																records.push(duplicaterecord);
																addclips(row,$.grep(records,function(item,index){
																	return $.fieldequals(item[vars.config['employee']].value,record[vars.config['employee']].value,vars.fieldinfos[vars.config['employee']]);
																}));
																/* close form */
																vars.form.hide();
															});
														});
													}
												},
												delete:function(){
													var recordid=record['$id'].value;
													if (recordid)
													{
														swalTis({
															title:'確認',
															text:'削除します。\n宜しいですか?',
															icon:'warning',
															buttons:{
																cancel:{
																	text:'キャンセル',
																	visible:true
																},
																confirm:{
																	text:'OK',
																	visible:true
																}
															}
														}).then(function(isConfirm){
															if (!isConfirm) return;
															var body={
																app:kintone.app.getId(),
																ids:[recordid]
															};
															kintone.api(kintone.api.url('/k/v1/records',true),'DELETE',body,function(resp){
																records=$.grep(records,function(item,index){
																	return item['$id'].value!=recordid;
																});
																/* reload clips */
																addclips(row,$.grep(records,function(item,index){
																	return $.fieldequals(item[vars.config['employee']].value,record[vars.config['employee']].value,vars.fieldinfos[vars.config['employee']]);
																}));
																/* close form */
																vars.form.hide();
															},function(error){
																swalTis('Error!',$.builderror(error),'error');
																/* close form */
																vars.form.hide();
															});
														});
													}
												},
												cancel:function(){
													/* close form */
													vars.form.hide();
												},
												record:function(){
													window.location.href=kintone.api.url('/k/', true).replace(/\.json/g,'')+kintone.app.getId()+'/show#record='+record['$id'].value.toString()+$.breadcrumbsparams();
												}
											},
											values:(function(record){
												var res=$.extend(true,{},record);
												res[vars.config['employee']+'_formlabel']={type:'SINGLE_LINE_TEXT',value:recordkeys.display};
												return res;
											})(record)
										});
										e.stopPropagation();
									})
								),
								'workshift-hover',
								'workshift-cell',
								function(e){
									if (vars.config['dragcancel']=='1') {e.cancel=true;return;}
									e.dataTransfer.setData('keys',JSON.stringify({
										cellindex:clipinfo.pos.from,
										recordid:record['$id'].value,
										span:(clipinfo.pos.to-clipinfo.pos.from+1).toString()
									}));
								},
								function(e,fromrow,torow,cellindex){
									/* update record */
									var keys=JSON.parse(e.dataTransfer.getData('keys'));
									var fromtime=(function(time){
										time=time.calc(((cellindex-keys.cellindex)*unitminute).toString()+' minute');
										if (time.getHours()+time.getMinutes()==0) time.calc('-1 second');
										return time.format('Y-m-d H:i').replace(/ /g,'T')+':00'+$.timezome()
									})(new Date(record[vars.config['shiftfromtime']].value.dateformat()));
									var totime=(function(time){
										time=time.calc(((cellindex-keys.cellindex)*unitminute).toString()+' minute');
										if (time.getHours()+time.getMinutes()==0) time.calc('-1 second');
										return time.format('Y-m-d H:i').replace(/ /g,'T')+':00'+$.timezome()
									})(new Date(record[vars.config['shifttotime']].value.dateformat()));
									var fromrecordkeys=createfieldvalue(JSON.parse(fromrow.find('#recordkeys').val()).value,vars.fieldinfos[vars.config['employee']]);
									var torecordkeys=createfieldvalue(JSON.parse(torow.find('#recordkeys').val()).value,vars.fieldinfos[vars.config['employee']]);
									var body={
										app:kintone.app.getId(),
										id:keys.recordid,
										record:{}
									};
									body.record[vars.config['shiftfromtime']]={value:fromtime};
									body.record[vars.config['shifttotime']]={value:totime};
									body.record[vars.config['employee']]={value:torecordkeys.value};
									kintone.api(kintone.api.url('/k/v1/record',true),'PUT',body,function(resp){
										record[vars.config['shiftfromtime']].value=fromtime;
										record[vars.config['shifttotime']].value=totime;
										record[vars.config['employee']].value=torecordkeys.value;
										/* reload clips */
										addclips(fromrow,$.grep(records,function(item,index){
											return $.fieldequals(item[vars.config['employee']].value,fromrecordkeys.value,vars.fieldinfos[vars.config['employee']]);
										}));
										addclips(torow,$.grep(records,function(item,index){
											return $.fieldequals(item[vars.config['employee']].value,torecordkeys.value,vars.fieldinfos[vars.config['employee']]);
										}));
									},function(error){
										swalTis('Error!',$.builderror(error),'error');
									});
								},
								'workshift-resize',
								function(cellindex){
									/* update record */
									var totime=(function(time){
										if (time.getHours()+time.getMinutes()==0) time.calc('-1 second');
										return time.format('Y-m-d H:i').replace(/ /g,'T')+':00'+$.timezome()
									})(new Date(vars.table.cols[cellindex][0].find('input').val().dateformat()).calc(unitminute.toString()+' minute'));
									var body={
										app:kintone.app.getId(),
										id:record['$id'].value,
										record:{}
									};
									body.record[vars.config['shifttotime']]={value:totime};
									kintone.api(kintone.api.url('/k/v1/record',true),'PUT',body,function(resp){
										record[vars.config['shifttotime']].value=totime;
										/* reload clips */
										addclips(row,$.grep(records,function(item,index){
											return $.fieldequals(item[vars.config['employee']].value,record[vars.config['employee']].value,vars.fieldinfos[vars.config['employee']]);
										}));
									},function(error){
										swalTis('Error!',$.builderror(error),'error');
									});
								}
							));
						})(filter[i]);
					vars.table.resetsticky();
					vars.toolbar.parent().css({'z-index':(vars.table.stickyindex+1).toString()});
					/* display calculate worktime */
					functions.displayworktime();
				};
				var createfieldvalue=function(value,fieldinfo){
					var res={type:fieldinfo.type,value:null};
					switch (fieldinfo.type)
					{
						case 'CHECK_BOX':
						case 'MULTI_SELECT':
							res.value=(value)?[value]:[];
							break;
						case 'FILE':
							res.value=(value)?[{fileKey:value}]:[];
							break;
						case 'GROUP_SELECT':
						case 'ORGANIZATION_SELECT':
						case 'USER_SELECT':
							res.value=(value)?[{code:value}]:[];
							break;
						default:
							res.value=value;
							break;
					}
					return res;
				};
				/* initialize valiable */
				vars.worktimes={};
				/* create row labels */
				head.eq(0).append($('<th class="workshift-rowhead workshift-unfixedcolumn" rowspan="3">').html('&nbsp;'));
				head.eq(1).append($('<th class="workshift-rowhead">').hide());
				head.eq(2).append($('<th class="workshift-rowhead">').hide());
				template.append($('<td class="workshift-rowhead">'));
				/* create cells */
				for (var i=0;i<vars.dateinfo.diffhours;i++)
				{
					var hide='';
					if (columns.cache.getHours()<parseInt(vars.config['starthour'])) hide=' hide';
					if (columns.cache.getHours()>parseInt(vars.config['endhour'])) hide=' hide';
					if (i!=0 && columns.cache.getHours()==0)
					{
						var cellindex=head.eq(0).find('th').last()[0].cellIndex;
						head.eq(0).find('th').eq(columns.index).attr('colspan',columns.span);
						for (var i2=columns.index+1;i2<cellindex+1;i2++) head.eq(0).find('th').eq(i2).addClass('hide');
						columns.index=cellindex+1;
						columns.span=0;
					}
					for (var i2=0;i2<parseInt(vars.config['scale']);i2++)
					{
						var minute=unitminute*i2;
						head.eq(0).append($('<th class="workshift-columnhead">')
							.append($('<span>').html(columns.cache.format('m-d')+'（'+week[columns.cache.getDay()]+'）'))
							.append($('<input type="hidden">').val(columns.cache.format('Y-m-d')+'T'+columns.cache.calc(minute.toString()+' minute').format('H:i')+':00'+$.timezome()))
						);
						head.eq(1).append($('<th class="workshift-columnhead'+hide+'">').html(columns.cache.getHours()));
						head.eq(2).append($('<th class="workshift-columnhead'+hide+'">'));
						template.append($('<td class="workshift-cell'+hide+'">'));
						if (i2==0) head.eq(1).find('th').last().attr('colspan',vars.config['scale']);
						else head.eq(1).find('th').last().addClass('hide');
						if (!hide) columns.span++;
					}
					columns.cache=columns.cache.calc('1 hour');
				}
				head.eq(0).find('th').eq(columns.index).attr('colspan',columns.span);
				for (var i=columns.index+1;i<head.eq(0).find('th').length;i++) head.eq(0).find('th').eq(i).hide();
				/* create table */
				vars.toolbar=$('.gaia-header-toolbar');
				vars.table=$('<table id="workshift" class="customview-table workshift">').dynamictable({
					container:container.empty(),
					head:head,
					template:template,
					trace:{
						activeclass:'workshift-trace',
						rangeclass:'workshift-cell',
						callback:function(caller,row,cellfrom,cellto){
							var record={};
							record[vars.config['shiftfromtime']]={type:vars.fieldinfos[vars.config['shiftfromtime']].type,value:vars.table.cols[cellfrom][0].find('input').val()};
							record[vars.config['shifttotime']]={type:vars.fieldinfos[vars.config['shifttotime']].type,value:(function(time){
								if (time.getHours()+time.getMinutes()==0) time.calc('-1 second');
								return time.format('Y-m-d H:i').replace(/ /g,'T')+':00'+$.timezome()
							})(new Date(vars.table.cols[cellto][0].find('input').val().dateformat()).calc(unitminute.toString()+' minute'))};
							record[vars.config['employee']]=createfieldvalue(JSON.parse(row.find('#recordkeys').val()).value,vars.fieldinfos[vars.config['employee']]);
							record[vars.config['employee']+'_formlabel']={type:'SINGLE_LINE_TEXT',value:JSON.parse(row.find('#recordkeys').val()).display};
							for (var i=0;i<vars.editables.length;i++) record[vars.editables[i]]=createfieldvalue(null,vars.fieldinfos[vars.editables[i]]);
							/* show registration form */
							if (vars.config['pagetransfer']=='1')
							{
								var transfer=$.extend(true,{},record);
								for (var i=0;i<vars.editables.length;i++) delete transfer[vars.editables[i]];
								sessionStorage.setItem('workshift-transfer',JSON.stringify(transfer));
								window.location.href=kintone.api.url('/k/', true).replace(/\.json/g,'')+kintone.app.getId()+'/edit'+$.breadcrumbsparams().replace(/^&/g,'?');
								return;
							}
							vars.form.dialog.container.children('div').eq(1).find('#record').hide();
							vars.form.dialog.container.children('div').eq(1).find('#duplicate').hide();
							vars.form.dialog.container.children('div').eq(1).find('#delete').hide();
							vars.form.show({
								buttons:{
									ok:function(){
										/* create insert values */
										record[vars.config['shiftfromtime']]=vars.form.fieldvalue(vars.fieldinfos[vars.config['shiftfromtime']]);
										record[vars.config['shifttotime']]=vars.form.fieldvalue(vars.fieldinfos[vars.config['shifttotime']]);
										for (var i=0;i<vars.editables.length;i++) record[vars.editables[i]]=vars.form.fieldvalue(vars.fieldinfos[vars.editables[i]]);
										/* insert record */
										kintone.api(kintone.api.url('/k/v1/record',true),'POST',{app:kintone.app.getId(),record:record},function(resp){
											kintone.api(kintone.api.url('/k/v1/record',true),'GET',{app:kintone.app.getId(),id:resp.id},function(resp){
												/* reload clips */
												records.push(resp.record);
												addclips(row,$.grep(records,function(item,index){
													return $.fieldequals(item[vars.config['employee']].value,record[vars.config['employee']].value,vars.fieldinfos[vars.config['employee']]);
												}));
												/* close form */
												vars.form.hide();
											},function(error){
												swalTis('Error!',$.builderror(error),'error');
												/* close form */
												vars.form.hide();
											});
										},function(error){
											swalTis('Error!',$.builderror(error),'error');
											/* close form */
											vars.form.hide();
										});
									},
									cancel:function(){
										/* close form */
										vars.form.hide();
									}
								},
								values:record
							});
						}
					},
					guide:{
						activeclass:'workshift-hover',
						rangeclass:'workshift-cell'
					},
					fixrow:{
						top:vars.toolbar.outerHeight(false)
					},
					fixcolumn:{
						activeclass:'workshift-fixedcolumn',
						columns:1
					}
				});
				/* place records */
				var colorindex=0;
				vars.table.clearrows();
				for (var i=0;i<vars.apps['employee'].length;i++)
				{
					(function(employee){
						if (vars.config['assignment'].length!=0)
							if ($.inArray($('select.assignment').val(),employee.assignment)<0) return;
						/* append row */
						addrow($.grep(records,function(item,index){
							var exists=false;
							var fieldinfo=vars.fieldinfos[vars.config['employee']];
							switch (fieldinfo.type)
							{
								case 'USER_SELECT':
									for (var i2=0;i2<item[vars.config['employee']].value.length;i2++)
										if (item[vars.config['employee']].value[i2].code==employee.value) exists=true;
									break;
								default:
									if (item[vars.config['employee']].value==employee.value) exists=true;
									break;
							}
							return exists;
						}),employee,colorindex);
						colorindex++;
					})(vars.apps['employee'][i]);
				}
				if (vars.config['scalefixed']=='1')
				{
					var width=0;
					head.eq(0).find('.workshift-rowhead').each(function(index){
						width+=$(this).outerWidth(false);
						$(this).css({'width':$(this).outerWidth(false).toString()+'px'});
					});
					head.eq(2).find('.workshift-columnhead').css({'width':vars.config['scalefixedwidth']+'px'});
					vars.table.container.css({
						'table-layout':'fixed',
						'width':(width+head.eq(2).find('.workshift-columnhead:visible').length*parseInt(vars.config['scalefixedwidth'])).toString()+'px'
					});
					/* adjust size of clip */
					$('.workshift-clip').each(function(index){
						var cell=$(this).parent();
						$(this).css({
							'width':(function(from,to){
								var res=0;
								res+=vars.table.cols[to][2][0].getBoundingClientRect().right;
								res-=vars.table.cols[from][2][0].getBoundingClientRect().left;
								return (Math.abs(res)-5).toString();
							})(parseInt($('.workshift-clipspanfrom',$(this)).val()),parseInt($('.workshift-clipspanto',$(this)).val()))+'px',
						});
					});
				}
				/* adjust size of clip */
				$(window).on('resize',function(e){
					$('.workshift-clip').each(function(index){
						var cell=$(this).parent();
						$(this).css({
							'width':(function(from,to){
								var res=0;
								res+=vars.table.cols[to][2][0].getBoundingClientRect().right;
								res-=vars.table.cols[from][2][0].getBoundingClientRect().left;
								return (Math.abs(res)-5).toString();
							})(parseInt($('.workshift-clipspanfrom',$(this)).val()),parseInt($('.workshift-clipspanto',$(this)).val()))+'px',
						});
					});
				});
			});
		},
		/* reload datas */
		loaddatas:function(app,query,sort,callback){
			$.cursorcreate({
				app:app,
				query:query,
				sort:sort
			},function(id,total,error){
				if (error) swalTis('Error!',error,'error');
				else
				{
					$.cursorfetch(id,true,function(records,error){
						if (error) swalTis('Error!',error,'error');
						else callback(records);
					});
				}
			});
		}
	};
	/*---------------------------------------------------------------
	 kintone events
	---------------------------------------------------------------*/
	kintone.events.on(events.lists,function(event){
		vars.config=kintone.plugin.app.getConfig(PLUGIN_ID);
		if (!vars.config) return false;
		/* check viewid */
		if (event.viewId!=vars.config.workshift) return;
		/* initialize valiable */
		var container=$('div#workshift-container');
		var feed=$('<div class="workshift-headermenucontents">');
		var date=$('<span id="date" class="customview-span datedisplay">');
		var week=$('<span id="week" class="customview-span weekdisplay">');
		var month=$('<span id="month" class="customview-span monthdisplay">');
		var button=$('<button id="datepick" class="customview-button calendar-button">');
		var prev=$('<button id="prev" class="customview-button prev-button">');
		var next=$('<button id="next" class="customview-button next-button">');
		var assignment=$('<div class="kintoneplugin-select-outer">').append($('<div class="kintoneplugin-select">').append($('<select class="assignment">')));
		var viewtype=$('<div class="kintoneplugin-select-outer">').append($('<div class="kintoneplugin-select">').append($('<select class="viewtype">')));
		$('select',viewtype).append($('<option>').attr('value','0').html('&nbsp;日次&nbsp;').prop('checked',true));
		$('select',viewtype).append($('<option>').attr('value','1').html('&nbsp;週次&nbsp;'));
		$('select',viewtype).append($('<option>').attr('value','2').html('&nbsp;月次&nbsp;'));
		$('select',viewtype).on('change',function(){
			/* adjust pickup dates */
			functions.adjustdates();
			/* reload view */
			functions.load();
		});
		vars.legend=$('<div class="workshift-legend">');
		/* append elements */
		feed.append(viewtype);
		feed.append(assignment);
		feed.append(prev);
		feed.append(date);
		feed.append(week);
		feed.append(month);
		feed.append(button);
		feed.append(next);
		if ($('.custom-elements-workshift').size()) $('.custom-elements-workshift').remove();
		kintone.app.getHeaderMenuSpaceElement().appendChild(feed.addClass('custom-elements-workshift')[0]);
		kintone.app.getHeaderMenuSpaceElement().appendChild($('<button class="kintoneplugin-button-dialog-ok downloadschedule">').addClass('custom-elements-workshift')[0]);
		kintone.app.getHeaderSpaceElement().appendChild(vars.legend.addClass('custom-elements-workshift')[0]);
		/* fixed header */
		var headeractions=$('div.contents-actionmenu-gaia');
		var headerspace=$(kintone.app.getHeaderSpaceElement());
		headeractions.parent().css({'position':'relative'});
		headerspace.parent().css({'position':'relative'});
		$(window).on('load resize scroll',function(e){
			headeractions.css({
				'left':$(window).scrollLeft().toString()+'px',
				'position':'absolute',
				'top':'0px',
				'width':$(window).width().toString()+'px'
			});
			headerspace.css({
				'left':$(window).scrollLeft().toString()+'px',
				'position':'absolute',
				'top':headeractions.outerHeight(false)+'px',
				'width':$(window).width().toString()+'px'
			});
			container.css({'margin-top':(headeractions.outerHeight(false)+headerspace.outerHeight(false))+'px','overflow-x':'visible'});
		});
		/* download pdf */
		$('.downloadschedule').text('勤務予定表ダウンロード').on('click',function(e){functions.downloadschedule();});
		/* setup date value */
		functions.adjustdates();
		/* day pickup button */
		vars.calendar=$('body').calendar({
			selected:function(target,value){
				vars.fromdate=new Date(value.dateformat());
				/* adjust pickup dates */
				functions.adjustdates();
				/* reload view */
				functions.load();
			}
		});
		button.on('click',function(){
			vars.calendar.show({activedate:vars.fromdate});
		});
		/* day feed button */
		$.each([prev,next],function(){
			$(this).on('click',function(){
				var add=0;
				switch ($('select.viewtype').val())
				{
					case '0':
						add=($(this).attr('id')=='next')?1:-1;
						vars.fromdate=vars.fromdate.calc(add+' day');
						break;
					case '1':
						add=($(this).attr('id')=='next')?7:-7;
						vars.fromdate=vars.fromdate.calc(add+' day');
						break;
					case '2':
						add=($(this).attr('id')=='next')?1:-1;
						vars.fromdate=vars.fromdate.calc(add+' month');
						break;
				}
				/* setup date value */
				functions.adjustdates();
				/* reload view */
				functions.load();
			});
		});
		/* setup colors value */
		vars.colors=$.grep(vars.config['employeecolors'].split(','),function(item,index){return item!='';});
		/* get fields of app */
		kintone.api(kintone.api.url('/k/v1/app/form/fields',true),'GET',{app:kintone.app.getId(),lang:'user'},function(resp){
			vars.fieldinfos=resp.properties;
			/* create registration form */
			vars.editables=$.grep(vars.config['editables'].split(','),function(item,index){return item!='';});
			vars.form=$('body').fieldsform({fields:(function(fieldinfos){
				var res=[];
				res.push(vars.fieldinfos[vars.config['shiftfromtime']]);
				res.push(vars.fieldinfos[vars.config['shifttotime']]);
				res.push({
					type:'SINGLE_LINE_TEXT',
					code:vars.config['employee']+'_formlabel',
					label:vars.fieldinfos[vars.config['employee']].label
				});
				for (var i=0;i<vars.editables.length;i++) res.push(vars.fieldinfos[vars.editables[i]]);
				return res;
			})(vars.fieldinfos)});
			vars.form.dialog.cover.addClass('custom-elements-workshift');
			$('.container',vars.form.dialog.container).each(function(index){
				switch ($(this).attr('id'))
				{
					case vars.config['shiftfromtime']:
					case vars.config['shifttotime']:
						$(this).css({'display':'inline-block','width':'50%'});
						break;
					case vars.config['employee']+'_formlabel':
						$(this).find('.receiver').attr('readonly',true).css({'border':'none'});
						break;
				}
			});
			(function(container){
				container
				.prepend(
					container.find('button').eq(0).clone(false)
					.attr('id','record')
					.text('詳細画面へ')
				);
				container.find('#cancel')
				.before(
					container.find('button').eq(0).clone(false)
					.attr('id','duplicate')
					.text('複製')
				)
				.before(
					container.find('button').eq(0).clone(false)
					.attr('id','delete')
					.text('削除')
				);
			})(vars.form.dialog.container.css({'width':'700px'}).children('div').eq(1));
			/* get datas of employee */
			$.loademployees(vars.config,vars.fieldinfos,vars.apps,function(){
				if (vars.config['assignment'].length!=0)
				{
					/* sort assignment */
					vars.apps['assignment']=(function(base){
						var sorted={};
						var keys=Object.keys(base);
						keys.sort();
						if (vars.config['assignmentsort']=='asc') for (var i=0;i<keys.length;i++) sorted[keys[i]]=base[keys[i]];
						else for (var i=keys.length-1;i>-1;i--) sorted[keys[i]]=base[keys[i]];
						return sorted;
					})(vars.apps['assignment']);
					/* setup assignment */
					$.each(vars.apps['assignment'],function(key,values){
						$('select',assignment).append($('<option>').attr('value',key).html('&nbsp;'+values+'&nbsp;'));
					});
					$('select',assignment).on('change',function(){
						/* reload view */
						functions.load();
					});
				}
				else assignment.hide();
				/* reload view */
				functions.load();
			});
		},function(error){});
		return event;
	});
	kintone.events.on(events.show,function(event){
		if (sessionStorage.getItem('workshift-transfer'))
			(function(transfer){
				for (var key in transfer)
					if (key in event.record)
					{
						event.record[key].value=transfer[key].value;
						event.record[key].lookup=true;
					}
			})(JSON.parse(sessionStorage.getItem('workshift-transfer')));
		sessionStorage.removeItem('workshift-transfer');
		return event;
	});
})(jTis,kintone.$PLUGIN_ID);
