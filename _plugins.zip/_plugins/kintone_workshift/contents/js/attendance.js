/*
*--------------------------------------------------------------------
* Kintone-Plugin "attendance"
* Version: 1.0
* Copyright (c) 2016 TIS
*
* Released under the MIT License.
* http://tis2010.jp/license.txt
* -------------------------------------------------------------------
*/
jTis.noConflict();
(function($,PLUGIN_ID){
	"use strict";
	/*---------------------------------------------------------------
	 valiable
	---------------------------------------------------------------*/
	var vars={
		fromdate:new Date(),
		todate:new Date(),
		table:null,
		toolbar:null,
		apps:{},
		config:{},
		fieldinfos:{}
	};
	var events={
		lists:[
			'app.record.index.show'
		]
	};
	var functions={
		/* download attendance file */
		downloadattendance:function(){
			var lines='';
			lines+='"氏名",';
			lines+='"出勤",';
			lines+='"欠勤",';
			lines+='"実働",';
			lines+='"遅刻・早退",';
			lines+='"深夜勤務",';
			lines+='"普通残業",';
			lines+='"深夜残業"';
			lines+='\n';
			$.each(vars.table.rows,function(index){
				var row=$(this);
				var line='';
				lines+='"'+$('td',row).eq(0).text()+'",';
				lines+=$('td',row).eq(1).text().replace(/[,H日]/g,'')+',';
				lines+=$('td',row).eq(2).text().replace(/[,H日]/g,'')+',';
				lines+=$('td',row).eq(3).text().replace(/[,H日]/g,'')+',';
				lines+=$('td',row).eq(4).text().replace(/[,H日]/g,'')+',';
				lines+=$('td',row).eq(5).text().replace(/[,H日]/g,'')+',';
				lines+=$('td',row).eq(6).text().replace(/[,H日]/g,'')+',';
				lines+=$('td',row).eq(7).text().replace(/[,H日]/g,'')+',';
				lines+='\n';
			});
			$.downloadtext(lines,vars.config['charactercode'],'出勤簿'+vars.fromdate.format('Y-m')+'.csv');
		},
		/* reload view */
		load:function(){
			/* after apprecords acquisition,rebuild view */
			functions.loaddatas(kintone.app.getId(),(function(){
				var res=kintone.app.getQueryCondition();
				if (res) res='('+res+') and ';
				res+=vars.config['shiftfromtime']+'>"'+vars.fromdate.calc('-1 day').format('Y-m-d')+'T23:59:59'+$.timezome()+'"';
				res+=' and '+vars.config['shiftfromtime']+'<"'+vars.todate.calc('1 day').format('Y-m-d')+'T00:00:00'+$.timezome()+'"';
				return res;
			})(),vars.config['shiftfromtime']+' asc',function(records){
				/* place the employee data */
				vars.table.clearrows();
				for (var i=0;i<vars.apps['employee'].length;i++)
					(function(employee){
						vars.table.addrow(null,function(row){
							var add=true;
							var night=0;
							var nightover=0;
							var over=0;
							var tardy=0;
							var work=0;
							var attendances=[];
							var absences=[];
							var filter=$.grep(records,function(item,index){
								var exists=false;
								var fieldinfo=vars.fieldinfos[vars.config['employee']];
								switch (fieldinfo.type)
								{
									case 'USER_SELECT':
										for (var i2=0;i2<item[vars.config['employee']].value.length;i2++)
											if (item[vars.config['employee']].value[i2].code==employee.value) exists=true;
										break;
									default:
										if (item[vars.config['employee']].value==employee.value) exists=true;
										break;
								}
								return exists;
							});
							for (var i2=0;i2<filter.length;i2++)
							{
								var shiftfrom=$.fieldvalue(filter[i2][vars.config['shiftfromtime']]).dateformat();
								var shiftto=$.fieldvalue(filter[i2][vars.config['shifttotime']]).dateformat();
								var workfrom=$.fieldvalue(filter[i2][vars.config['workfromtime']]).dateformat();
								var workto=$.fieldvalue(filter[i2][vars.config['worktotime']]).dateformat();
								var date=new Date(shiftfrom).format('Y-m-d').dateformat();
								var nightstart=new Date(shiftfrom).format('Y-m-d')+' 22:00:00';
								var nightend=new Date(date).calc('1 day').format('Y-m-d')+' 05:00:00';
								var dateinfo={};
								add=true;
								/* adjust work time */
								if (new Date(workfrom)<new Date(shiftfrom)) workfrom=shiftfrom;
								if (workto.length==0) workto=shiftto;
								/* calculate attendance */
								if (!(date in attendances))
								{
									if (workfrom.length!=0)
									{
										attendances.push(date);
										if (date in absences) absences.splice(absences.indexOf(date),1);
									}
									else
									{
										absences.push(date);
										add=false;
									}
								}
								else
								{
									if (workfrom.length==0) add=false;
								}
								if (!add) continue;
								/* calculate worktime */
								dateinfo=$.datecalc(new Date(workfrom),new Date(workto));
								work+=dateinfo.passedhours+(dateinfo.passedminutes/60);
								/* calculate come in late time */
								dateinfo=$.datecalc(new Date(shiftfrom),new Date(workfrom));
								if ((dateinfo.passedhours+dateinfo.passedminutes)>0) tardy+=dateinfo.passedhours+(dateinfo.passedminutes/60);
								/* calculate leave early time */
								dateinfo=$.datecalc(new Date(workto),new Date(shiftto));
								if ((dateinfo.passedhours+dateinfo.passedminutes)>0) tardy+=dateinfo.passedhours+(dateinfo.passedminutes/60);
								/* calculate over time */
								dateinfo=$.datecalc(new Date(shiftto),new Date(workto));
								if ((dateinfo.passedhours+dateinfo.passedminutes)>0) over+=dateinfo.passedhours+(dateinfo.passedminutes/60);
								/* calculate night time */
								if (new Date(workto)>new Date(nightend)) workto=nightend;
								dateinfo=$.datecalc(new Date(nightstart),new Date(workto));
								if ((dateinfo.passedhours+dateinfo.passedminutes)>0) night+=dateinfo.passedhours+(dateinfo.passedminutes/60);
								/* calculate night over time */
								if (new Date(shiftto)<new Date(nightstart)) shiftto=nightstart;
								dateinfo=$.datecalc(new Date(shiftto),new Date(workto));
								if ((dateinfo.passedhours+dateinfo.passedminutes)>0)
								{
									var addition=dateinfo.passedhours+(dateinfo.passedminutes/60);
									nightover+=addition;
									night-=addition;
									over-=addition;
								}
							}
							work=Math.ceil(work*100)/100;
							tardy=Math.ceil(tardy*100)/100;
							night=Math.ceil(night*100)/100;
							over=Math.ceil(over*100)/100;
							nightover=Math.ceil(nightover*100)/100;
							$('td',row).eq(0).html((employee.link)?employee.link:employee.display);
							$('td',row).eq(1).text(attendances.length.comma()+'日');
							$('td',row).eq(2).text(absences.length.comma()+'日');
							$('td',row).eq(3).text(work.comma()+'H');
							$('td',row).eq(4).text(tardy.comma()+'H');
							$('td',row).eq(5).text(night.comma()+'H');
							$('td',row).eq(6).text(over.comma()+'H');
							$('td',row).eq(7).text(nightover.comma()+'H');
							vars.toolbar.parent().css({'z-index':(vars.table.stickyindex+1).toString()});
						});
					})(vars.apps['employee'][i]);
			});
		},
		/* reload datas */
		loaddatas:function(app,query,sort,callback){
			$.cursorcreate({
				app:app,
				query:query,
				sort:sort
			},function(id,total,error){
				if (error) swalTis('Error!',error,'error');
				else
				{
					$.cursorfetch(id,true,function(records,error){
						if (error) swalTis('Error!',error,'error');
						else callback(records);
					});
				}
			});
		}
	};
	/*---------------------------------------------------------------
	 kintone events
	---------------------------------------------------------------*/
	kintone.events.on(events.lists,function(event){
		vars.config=kintone.plugin.app.getConfig(PLUGIN_ID);
		if (!vars.config) return false;
		/* check viewid */
		if (event.viewId!=vars.config.attendance) return;
		/* initialize valiable */
		var feed=$('<div class="workshift-headermenucontents">');
		var month=$('<span id="month" class="customview-span">');
		var prev=$('<button id="prev" class="customview-button prev-button">');
		var next=$('<button id="next" class="customview-button next-button">');
		/* append elements */
		feed.append(prev);
		feed.append(month);
		feed.append(next);
		if ($('.custom-elements-attendance').size()) $('.custom-elements-attendance').remove();
		kintone.app.getHeaderMenuSpaceElement().appendChild(feed.addClass('custom-elements-attendance')[0]);
		kintone.app.getHeaderMenuSpaceElement().appendChild($('<button class="kintoneplugin-button-dialog-ok downloadattendance">').addClass('custom-elements-attendance')[0]);
		$('.downloadattendance')
		.text('CSVダウンロード')
		.on('click',function(e){functions.downloadattendance();});
		/* setup date value */
		vars.fromdate=vars.fromdate.calc('first-of-month');
		vars.todate=vars.fromdate.calc('1 month').calc('-1 day');
		month.text(vars.fromdate.format('Y-m'));
		/* day feed button */
		$.each([prev,next],function(){
			$(this).on('click',function(){
				var months=($(this).attr('id')=='next')?1:-1;
				vars.fromdate=vars.fromdate.calc(months+' month');
				vars.todate=vars.fromdate.calc('1 month').calc('-1 day');
				month.text(vars.fromdate.format('Y-m'));
				/* reload view */
				functions.load();
			});
		});
		/* get fields of app */
		kintone.api(kintone.api.url('/k/v1/app/form/fields',true),'GET',{app:kintone.app.getId(),lang:'user'},function(resp){
			vars.fieldinfos=resp.properties;
			/* get datas of employee */
			$.loademployees(vars.config,vars.fieldinfos,vars.apps,function(){
				/* create table */
				var head=$('<tr>');
				var template=$('<tr>');
				head.append($('<th>').text('氏名'));
				head.append($('<th>').text('出勤'));
				head.append($('<th>').text('欠勤'));
				head.append($('<th>').text('実働'));
				head.append($('<th>').text('遅刻・早退'));
				head.append($('<th>').text('深夜勤務'));
				head.append($('<th>').text('普通残業'));
				head.append($('<th>').text('深夜残業'));
				template.append($('<td>'));
				template.append($('<td>'));
				template.append($('<td>'));
				template.append($('<td>'));
				template.append($('<td>'));
				template.append($('<td>'));
				template.append($('<td>'));
				template.append($('<td>'));
				vars.toolbar=$('.gaia-header-toolbar');
				vars.table=$('<table id="workshift" class="customview-table attendance">').dynamictable({
					container:$('div#workshift-container').empty(),
					head:head,
					template:template,
					fixrow:{
						top:vars.toolbar.outerHeight(false)
					}
				});
				/* reload view */
				functions.load();
			});
		},function(error){});
		return event;
	});
})(jTis,kintone.$PLUGIN_ID);
