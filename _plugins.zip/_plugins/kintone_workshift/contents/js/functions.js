(function($){
jTis.extend({
	datecalc:function(from,to,base){
		if (!base) base=from;
		var fromdiff=from.getTime()-base.getTime();
		var todiff=to.getTime()-base.getTime();
		var basetime={
			hour:base.getHours(),
			minute:base.getMinutes()
		};
		var fromtime={
			day:fromdiff/(1000*60*60*24),
			hour:basetime.hour+Math.floor((basetime.minute+fromdiff/(1000*60))/60),
			minute:(basetime.minute+fromdiff/(1000*60))%60
		};
		var totime={
			day:todiff/(1000*60*60*24),
			hour:basetime.hour+Math.floor((basetime.minute+todiff/(1000*60))/60),
			minute:(basetime.minute+todiff/(1000*60))%60
		};
		var values={
			diffhours:Math.ceil((to.getTime()-from.getTime())/(1000*60*60)),
			diffminutes:Math.ceil((to.getTime()-from.getTime())/(1000*60)),
			passedhours:Math.floor((to.getTime()-from.getTime())/(1000*60*60)),
			passedminutes:Math.floor(((to.getTime()-from.getTime())/(1000*60))%60),
			from:fromtime,
			to:totime
		};
		return values;
	},
	loademployees:function(config,fieldinfos,apps,callback){
		var fieldinfo=fieldinfos[config['employee']];
		var host=kintone.api.url('/k/',true).replace(/\.json/g,'');
		if (!('assignment' in apps)) apps['assignment']={};
		if (!('employee' in apps)) apps['employee']=[];
		switch (fieldinfo.type)
		{
			case 'USER_SELECT':
				$.loadusers(function(records){
					var setuprecords=function(records,index,callback){
						if (index<records.length)
						{
							var record={display:records[index].name,link:'',value:records[index].code,assignment:[]};
							if (config['assignment'].length!=0)
							{
								(function(record){
									switch (config['assignment'])
									{
										case '0':
											kintone.api(kintone.api.url('/v1/user/organizations',true),'GET',{code:record.value},function(resp){
												for (var i=0;i<resp.organizationTitles.length;i++) record.assignment.push(resp.organizationTitles[i].organization.code);
												apps['employee'].push(record);
												index++;
												if (index<records.length) setuprecords(records,index,callback);
												else callback();
											},function(error){});
											break;
										case '1':
											kintone.api(kintone.api.url('/v1/user/groups',true),'GET',{code:record.value},function(resp){
												for (var i=0;i<resp.groups.length;i++) record.assignment.push(resp.groups[i].code);
												apps['employee'].push(record);
												index++;
												if (index<records.length) setuprecords(records,index,callback);
												else callback();
											},function(error){});
											break;
									}
								})(record);
							}
							else
							{
								apps['employee'].push(record);
								index++;
								if (index<records.length) setuprecords(records,index,callback);
								else callback();
							}
						}
						else callback();
					};
					setuprecords(records,0,function(){
						/* sort employee */
						apps['employee'].sort(function(a,b){
							if(a.value<b.value) return (config['employeesort']=='asc')?-1:1;
							if(a.value>b.value) return (config['employeesort']=='asc')?1:-1;
							return 0;
						});
						if (config['assignment'].length!=0)
						{
							switch (config['assignment'])
							{
								case '0':
									$.loadorganizations(function(records){
										for (var i=0;i<records.length;i++) apps['assignment'][records[i].code]=records[i].name;
										callback();
									});
									break;
								case '1':
									$.loadgroups(function(records){
										for (var i=0;i<records.length;i++) apps['assignment'][records[i].code]=records[i].name;
										callback();
									});
									break;
							}
						}
						else callback();
					});
				});
				break;
			default:
				$.cursorcreate({
					app:fieldinfo.lookup.relatedApp.app,
					query:fieldinfo.lookup.filterCond,
					sort:fieldinfo.lookup.relatedKeyField+' '+config['employeesort']
				},function(id,total,error){
					if (error) swalTis('Error!',error,'error');
					else
					{
						$.cursorfetch(id,true,function(records,error){
							if (error) swalTis('Error!',error,'error');
							else
							{
								for (var i=0;i<records.length;i++)
								{
									(function(record){
										apps['employee'].push({
											display:record[config['employeedisplay']].value,
											link:'<a href="'+host+fieldinfo.lookup.relatedApp.app+'/show#record='+record['$id'].value+'" target="_blank">'+record[config['employeedisplay']].value+'</a>',
											value:record[fieldinfo.lookup.relatedKeyField].value,
											assignment:(function(){
												var res=[];
												if (config['assignment'].length!=0)
												{
													var assignment=record[config['assignment']].value;
													res.push(assignment);
													if (!(assignment in apps['assignment'])) apps['assignment'][assignment]=assignment;
												}
												return res;
											})()
										});
									})(records[i])
								}
								callback();
							}
						});
					}
				});
				break;
		}
	}
});
})(jTis);
