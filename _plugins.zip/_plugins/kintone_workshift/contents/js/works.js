/*
*--------------------------------------------------------------------
* Kintone-Plugin "works"
* Version: 1.0
* Copyright (c) 2016 TIS
*
* Released under the MIT License.
* http://tis2010.jp/license.txt
* -------------------------------------------------------------------
*/
jTis.noConflict();
(function($,PLUGIN_ID){
	"use strict";
	/*---------------------------------------------------------------
	 valiable
	---------------------------------------------------------------*/
	var vars={
		date:new Date(),
		calendar:null,
		table:null,
		toolbar:null,
		apps:{},
		config:{},
		fieldinfos:{}
	};
	var events={
		lists:[
			'app.record.index.show'
		]
	};
	var functions={
		/* reload view */
		load:function(){
			/* after apprecords acquisition,rebuild view */
			functions.loaddatas(kintone.app.getId(),(function(){
				var res=kintone.app.getQueryCondition();
				if (res) res='('+res+') and ';
				res+=vars.config['shiftfromtime']+'>"'+vars.date.calc('-1 day').format('Y-m-d')+'T23:59:59'+$.timezome()+'"';
				res+=' and '+vars.config['shiftfromtime']+'<"'+vars.date.calc('1 day').format('Y-m-d')+'T00:00:00'+$.timezome()+'"';
				return res;
			})(),vars.config['shiftfromtime']+' asc',function(records){
				/* place the employee data */
				vars.table.clearrows();
				for (var i=0;i<vars.apps['employee'].length;i++)
					(function(employee){
						if (vars.config['assignment'].length!=0)
							if ($.inArray($('select.assignment').val(),employee.assignment)<0) return;
						var filter=$.grep(records,function(item,index){
							var exists=false;
							var fieldinfo=vars.fieldinfos[vars.config['employee']];
							switch (fieldinfo.type)
							{
								case 'USER_SELECT':
									for (var i2=0;i2<item[vars.config['employee']].value.length;i2++)
										if (item[vars.config['employee']].value[i2].code==employee.value) exists=true;
									break;
								default:
									if (item[vars.config['employee']].value==employee.value) exists=true;
									break;
							}
							return exists;
						});
						for (var i2=0;i2<filter.length;i2++)
							vars.table.addrow(null,function(row){
								var shiftfrom=new Date($.fieldvalue(filter[i2][vars.config['shiftfromtime']]).dateformat());
								var shiftto=new Date($.fieldvalue(filter[i2][vars.config['shifttotime']]).dateformat());
								var workfrom=$.fieldvalue(filter[i2][vars.config['workfromtime']]).dateformat();
								var workto=$.fieldvalue(filter[i2][vars.config['worktotime']]).dateformat();
								$('.workid',row).val(filter[i2]['$id'].value);
								$('td',row).eq(2).html((employee.link)?employee.link:employee.display);
								$('td',row).eq(3).text(shiftfrom.format('H:i')+' - '+shiftto.format('H:i'));
								if (workfrom.length==0)
								{
									$('.workstatus',row).val('start');
									$('.workpunch',row).addClass('start').text('勤務開始');
									$('td',row).eq(4).text('勤務開始待ち');
								}
								else
								{
									if (workto.length==0)
									{
										$('.workstatus',row).val('end');
										$('.workpunch',row).addClass('end').text('勤務終了');
										$('td',row).eq(4).text('勤務中');
									}
									else
									{
										$('.workstatus',row).val('');
										$('.workpunch',row).hide();
										$('td',row).eq(4).text('勤務終了');
									}
								}
								vars.toolbar.parent().css({'z-index':(vars.table.stickyindex+1).toString()});
							});
					})(vars.apps['employee'][i]);
			});
		},
		/* reload datas */
		loaddatas:function(app,query,sort,callback){
			$.cursorcreate({
				app:app,
				query:query,
				sort:sort
			},function(id,total,error){
				if (error) swalTis('Error!',error,'error');
				else
				{
					$.cursorfetch(id,true,function(records,error){
						if (error) swalTis('Error!',error,'error');
						else callback(records);
					});
				}
			});
		}
	};
	/*---------------------------------------------------------------
	 kintone events
	---------------------------------------------------------------*/
	kintone.events.on(events.lists,function(event){
		vars.config=kintone.plugin.app.getConfig(PLUGIN_ID);
		if (!vars.config) return false;
		/* check viewid */
		if (event.viewId!=vars.config.works) return;
		/* initialize valiable */
		var feed=$('<div class="workshift-headermenucontents">');
		var date=$('<span id="date" class="customview-span datedisplay">');
		var button=$('<button id="datepick" class="customview-button calendar-button">');
		var prev=$('<button id="prev" class="customview-button prev-button">');
		var next=$('<button id="next" class="customview-button next-button">');
		var assignment=$('<div class="kintoneplugin-select-outer">').append($('<div class="kintoneplugin-select">').append($('<select class="assignment">')));
		var week=['日','月','火','水','木','金','土'];
		/* append elements */
		feed.append(assignment);
		feed.append(prev);
		feed.append(date);
		feed.append(button);
		feed.append(next);
		if ($('.workshift-headermenucontents').size()) $('.workshift-headermenucontents').remove();
		kintone.app.getHeaderMenuSpaceElement().appendChild(feed[0]);
		/* setup date value */
		if (sessionStorage.getItem('date_works'))
		{
			vars.date=new Date(sessionStorage.getItem('date_works'));
			sessionStorage.removeItem('date_works');
		}
		date.text(vars.date.format('Y-m-d')+' ('+week[vars.date.getDay()]+')');
		/* day pickup button */
		vars.calendar=$('body').calendar({
			selected:function(target,value){
				vars.date=new Date(value.dateformat());
				date.text(value+' ('+week[vars.date.getDay()]+')');
				/* reload view */
				functions.load();
			}
		});
		button.on('click',function(){
			vars.calendar.show({activedate:vars.date});
		});
		/* day feed button */
		$.each([prev,next],function(){
			$(this).on('click',function(){
				var days=($(this).attr('id')=='next')?1:-1;
				vars.date=vars.date.calc(days+' day');
				date.text(vars.date.format('Y-m-d')+' ('+week[vars.date.getDay()]+')');
				/* reload view */
				functions.load();
			});
		});
		/* get fields of app */
		kintone.api(kintone.api.url('/k/v1/app/form/fields',true),'GET',{app:kintone.app.getId(),lang:'user'},function(resp){
			vars.fieldinfos=resp.properties;
			/* get datas of employee */
			$.loademployees(vars.config,vars.fieldinfos,vars.apps,function(){
				if (vars.config['assignment'].length!=0)
				{
					/* sort assignment */
					vars.apps['assignment']=(function(base){
						var sorted={};
						var keys=Object.keys(base);
						keys.sort();
						if (vars.config['assignmentsort']=='asc') for (var i=0;i<keys.length;i++) sorted[keys[i]]=base[keys[i]];
						else for (var i=keys.length-1;i>-1;i--) sorted[keys[i]]=base[keys[i]];
						return sorted;
					})(vars.apps['assignment']);
					/* setup assignment */
					$.each(vars.apps['assignment'],function(key,values){
						$('select',assignment).append($('<option>').attr('value',key).html('&nbsp;'+values+'&nbsp;'));
					});
					if (sessionStorage.getItem('assignment_works'))
					{
						$('select',assignment).val(sessionStorage.getItem('assignment_works'));
						sessionStorage.removeItem('assignment_works');
					}
					$('select',assignment).on('change',function(){
						/* reload view */
						functions.load();
					});
				}
				else assignment.hide();
				/* create table */
				var head=$('<tr>');
				var template=$('<tr>');
				head.append($('<th>'));
				head.append($('<th>'));
				head.append($('<th>').text('氏名'));
				head.append($('<th>').text('勤務予定時間'));
				head.append($('<th>').text('勤務状況'));
				template.append(
					$('<td>')
					.append(
						$('<button class="customview-button edit-button">').on('click',function(){
							var cell=$(this).closest('td');
							var index=$('.workid',cell).val();
							if (index.length!=0)
							{
								sessionStorage.setItem('date_works',vars.date.format('Y-m-d').dateformat());
								sessionStorage.setItem('assignment_works',$('select',assignment).val());
								window.location.href=kintone.api.url('/k/', true).replace(/\.json/g,'')+kintone.app.getId()+'/show#record='+index+$.breadcrumbsparams();
							}
						})
					)
					.append($('<input type="hidden" class="workid" value="">'))
				);
				template.append(
					$('<td>')
					.append(
						$('<button class="workpunch">').on('click',function(){
							var row=$(this).closest('tr');
							var index=$('.workid',row).val();
							var registtime=new Date();
							switch ($('.workstatus',row).val())
							{
								case 'start':
									swalTis({
										title:'確認',
										text:$('td',row).eq(2).text()+'さんの勤務開始処理をします。\n宜しいですか?',
										icon:'warning',
										buttons:{
											cancel:{
												text:'キャンセル',
												visible:true
											},
											confirm:{
												text:'OK',
												visible:true
											}
										}
									}).then(function(isConfirm){
										if (!isConfirm) return;
										var body={
											app:kintone.app.getId(),
											id:index,
											record:{}
										};
										body.record[vars.config['workfromtime']]={value:registtime.format('Y-m-d')+'T'+registtime.format('H:i')+':00'+$.timezome()};
										kintone.api(kintone.api.url('/k/v1/record',true),'PUT',body,function(resp){
											$('.workstatus',row).val('end');
											$('.workpunch',row).removeClass('start').addClass('end').text('勤務終了');
											$('td',row).eq(4).text('勤務中');
										},function(error){
											swalTis('Error!',$.builderror(error),'error');
										});
									});
									break;
								case 'end':
									swalTis({
										title:'確認',
										text:$('td',row).eq(2).text()+'さんの勤務終了処理をします。\n宜しいですか?',
										icon:'warning',
										buttons:{
											cancel:{
												text:'キャンセル',
												visible:true
											},
											confirm:{
												text:'OK',
												visible:true
											}
										}
									}).then(function(isConfirm){
										if (!isConfirm) return;
										var body={
											app:kintone.app.getId(),
											id:index,
											record:{}
										};
										body.record[vars.config['worktotime']]={value:registtime.format('Y-m-d')+'T'+registtime.format('H:i')+':00'+$.timezome()};
										kintone.api(kintone.api.url('/k/v1/record',true),'PUT',body,function(resp){
											$('.workstatus',row).val('');
											$('.workpunch',row).hide();
											$('td',row).eq(4).text('勤務終了');
										},function(error){
											swalTis('Error!',$.builderror(error),'error');
										});
									});
									break;
							}
						})
					)
					.append($('<input type="hidden" class="workstatus" value="">'))
				);
				template.append($('<td>'));
				template.append($('<td>'));
				template.append($('<td>'));
				vars.toolbar=$('.gaia-header-toolbar');
				vars.table=$('<table id="workshift" class="customview-table works">').dynamictable({
					container:$('div#workshift-container').empty(),
					head:head,
					template:template,
					fixrow:{
						top:vars.toolbar.outerHeight(false)
					}
				});
				/* reload view */
				functions.load();
			});
		},function(error){});
		return event;
	});
})(jTis,kintone.$PLUGIN_ID);
